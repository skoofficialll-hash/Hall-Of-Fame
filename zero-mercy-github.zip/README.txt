ZERO-MERCY HALL OF FAME
=======================

Is zip ke andar ek hi file hai: index.html

GITHUB PAGES PAR HOST KARNE KE STEPS
------------------------------------
1. github.com -> apna account -> "+" -> New repository
   Naam: zero-mercy    Visibility: Public    -> Create repository

2. Repo ke andar -> "Add file" -> "Upload files"
   Is zip se index.html nikalo (extract karo) aur drag karo
   -> "Commit changes"

   ZAROORI: GitHub zip ko khud extract nahi karta.
   Isliye pehle zip kholo, phir andar wali index.html upload karo.
   File repo ke ROOT me honi chahiye, kisi folder ke andar nahi.

3. Repo -> Settings -> left sidebar me "Pages"
   Source: "Deploy from a branch"
   Branch: main      Folder: / (root)
   -> Save

4. 1-2 minute baad site live:
   https://<aapka-username>.github.io/zero-mercy/

UPDATE KAISE KARE
-----------------
Repo -> index.html pe click -> pencil (Edit) icon -> naya content paste
-> Commit changes.  Ya "Add file -> Upload files" se wahi file dobara
upload kar do (purani replace ho jayegi). 1 minute me live.

SUPABASE (ek baar karna hai)
----------------------------
Deploy hone ke baad Supabase me:
Authentication -> URL Configuration
  Site URL      : https://<aapka-username>.github.io/zero-mercy/
  Redirect URLs : wahi link add karo

ADMIN
-----
Site kholo -> footer me "Admin" -> email + password (Supabase Auth se)
Naya champion add karne ke liye: Add champion

Dhyan rakho: index.html ka naam kabhi na badlo.
